﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using Devoir2.Models;

namespace Devoir2.Controllers
{
    public class HomeController : Controller
    {
        private readonly RedditContext context;
        private readonly ISession session;
        public HomeController(IHttpContextAccessor accessor, RedditContext context)
        {
            this.session = accessor.HttpContext.Session;
            this.context = context;
            JsonConvert.DefaultSettings = () => new JsonSerializerSettings
            {
                ReferenceLoopHandling = ReferenceLoopHandling.Ignore
            };
        }
        public IActionResult Index()
        {
            if (session.GetString("user") == null)
                return RedirectToAction("Login");
            var user = JsonConvert.DeserializeObject<User>(session.GetString("user"));
            ViewBag.userName = user.UserName;
            return View(context.Posts.OrderByDescending(p => p.UpVote).ThenBy(p => p.DownVote).ToList());
        }
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(string email, string password)
        {
            var user = context.Users.Where(u => u.Email == email).FirstOrDefault();
            if (user == null)
            {
                ViewBag.MessageErreur = "Adresse courriel ou mot de passe invalide. Si vous ne possédez pas de compte, cliquez sur le lien pour vous inscrire.";
                return View();
            }
            else
            {
                if (user.Password == password)
                {
                    // stocker l'objet user comme variable de sesion
                    session.SetString("user", JsonConvert.SerializeObject(user));
                    return RedirectToAction("Index");
                }
                else
                {
                    ViewBag.MessageErreur = "Adresse courriel ou mot de passe invalide. Si vous ne possédez pas de compte, cliquez sur le lien pour vous inscrire.";
                    return View();
                }
            }
        }
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Register(string username, string email, string password)
        {
            var userExist = context.Users.Where(u => u.Email == email).FirstOrDefault();
            if (userExist == null)
            {
                User user = new User()
                {
                    UserName = username,
                    Email = email,
                    Password = password
                };
                context.Add<User>(user);
                context.SaveChanges();
                return RedirectToAction("Login");
            }
            else
            {
                ViewBag.MessageErreur = "Un compte existe déjà avec ce courriel, cliquez sur le lien pour vous inscrire.";
                return View();
            }
        }
        [HttpGet]
        public IActionResult AddLink()
        {
            if (session.GetString("user") == null)
                return RedirectToAction("Login");
            var user = JsonConvert.DeserializeObject<User>(session.GetString("user"));
            ViewBag.userName = user.UserName;
            return View();
        }
        [HttpPost]
        public IActionResult AddLink(string link, string description)
        {
            if (session.GetString("user") == null)
                return RedirectToAction("Login");
            var user = JsonConvert.DeserializeObject<User>(session.GetString("user"));
            Post post = new Post()
            {
                Link = link,
                Description = description,
                PublicationDate = DateTime.Now,
                UpVote = 1,
                DownVote = 0,
                UserID = user.UserID
            };
            context.Add<Post>(post);
            context.SaveChanges();
            return RedirectToAction("MyLinks");
        }
        [HttpGet]
        public IActionResult MyLinks()
        {
            if (session.GetString("user") == null)
                return RedirectToAction("Login");
            var user = JsonConvert.DeserializeObject<User>(session.GetString("user"));
            ViewBag.userName = user.UserName;
            return View(context.Posts.Where(p => p.UserID == user.UserID).OrderByDescending(p => p.PublicationDate).ToList());
        }
        public IActionResult DeletePost(int postid)
        {
            System.Console.Error.WriteLine("postid : " + postid);
            if (session.GetString("user") == null)
                return RedirectToAction("Login");
            Post post = context.Posts.Where(p => p.PostID == postid).FirstOrDefault();
            context.Remove<Post>(post);
            context.SaveChanges();
            return RedirectToAction("MyLinks");
        }
        public IActionResult UpVote(int postid)
        {
            System.Console.Error.WriteLine("postid : " + postid);
            if (session.GetString("user") == null)
                return RedirectToAction("Login");
            Post post = context.Posts.Where(p => p.PostID == postid).FirstOrDefault();
            post.UpVote++;
            context.Update<Post>(post);
            context.SaveChanges();
            return RedirectToAction("Link", new { postid = postid });
        }
        public IActionResult DownVote(int postid)
        {
            if (session.GetString("user") == null)
                return RedirectToAction("Login");
            Post post = context.Posts.Where(p => p.PostID == postid).FirstOrDefault();
            post.DownVote++;
            context.Update<Post>(post);
            context.SaveChanges();
            return RedirectToAction("Link", new { postid = postid });
        }

        public IActionResult Logout()
        {
            session.Clear();
            return RedirectToAction("Login");
        }
        [HttpGet]
        public IActionResult Link(int postid)
        {
            if (session.GetString("user") == null)
                return RedirectToAction("Login");
            var user = JsonConvert.DeserializeObject<User>(session.GetString("user"));
            ViewBag.userName = user.UserName;
            Post post = context.Posts.Find(postid);
            return View(post);
        }
        [HttpPost]
        public IActionResult Link(int postid, string commentaire)
        {
            if (session.GetString("user") == null)
                return RedirectToAction("Login");
            var user = JsonConvert.DeserializeObject<User>(session.GetString("user"));
            ViewBag.userName = user.UserName;
            Comment comment = new Comment()
            {
                Description = commentaire,
                PublicationDate = DateTime.Now,
                UserID = user.UserID,
                PostID = postid
            };
            context.Add<Comment>(comment);
            context.SaveChanges();
            return RedirectToAction("Link", new { postid = postid });
        }
    }
}
