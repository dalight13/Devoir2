using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Devoir2.Models
{
    public class Post
    {
        [Key]
        public int PostID { get; set; }
        [Column(TypeName = "VARCHAR(100)")]
        public string Link { get; set; }
        [Column(TypeName = "VARCHAR(250)")]
        public string Description { get; set; }
        public DateTime PublicationDate { get; set; }
        public int UpVote { get; set; }
        public int DownVote { get; set; }
        public int UserID { get; set; }
        public virtual User User { get; set; }
        public virtual ICollection<Comment> Comments { get; set; }
    }
}