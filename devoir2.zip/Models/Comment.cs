using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Devoir2.Models
{
    public class Comment
    {
        [Key]
        public int CommentID { get; set; }
        [Column(TypeName = "VARCHAR(250)")]
        public string Description { get; set; }
        public DateTime PublicationDate { get; set; }
        public int UserID { get; set; }
        public virtual User User { get; set; }
        public int PostID { get; set; }
        public virtual Post Post { get; set; }
    }
}