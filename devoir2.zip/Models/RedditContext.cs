using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace Devoir2.Models
{
    public class RedditContext : DbContext
    {
        public RedditContext()
        {

        }
        public RedditContext(DbContextOptions<RedditContext> options) : base(options)
        {

        }
        public DbSet<User> Users { get; set; }
        public DbSet<Post> Posts { get; set; }
        public DbSet<Comment> Comments { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            //terminal : dotnet ef migrations add MigrationName
            //dotnet ef database update
        }

    }
}